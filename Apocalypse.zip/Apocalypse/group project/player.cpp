#include "point.hpp"
#include "player.hpp"
#include "plane.hpp"
#include "Sky.hpp"
#include <graphics.h>
Player::Player(Point location = 0, int width = 0, int height = 0, int dx = 0, int dy = 0) : Plane(location, width, height, dx, dy)
{
}

Player ::Player(int x = 0, int y = 0, int width = 0, int height = 0, int dx = 0, int dy = 0) : Plane(x, y, width, height, dx, dy)
{
}

void Player::draw() const
{
    readimagefile("plane2.jpg", this->location.getX(), this->location.getY(), this->location.getX() + width, this->location.getY() + height);
}

void Player ::move(int dx = 0, int dy = 0)
{
    undraw();
    location.move(dx, dy);

    if (getRight() >= r->getRight())
    {
        location.setX(r->getRight() - width);
    }

    else if (getX() <= r->getX())
    {
        location.setX(r->getX());
    }

    if (getBottom() >= r->getBottom())
    {
        location.setY(r->getBottom() - height);
    }

    else if (getY() <= r->getY())
    {
        location.setY(r->getY());
    }

    draw();
}
