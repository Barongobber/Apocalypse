#ifndef PLAYER_H
#define PLAYER_H
#include "point.hpp"
#include "Sky.hpp"
#include "plane.hpp"


class Player : public Plane
{
public:
    Player (Point location  , int width, int height, int dx, int dy);
    Player (int x, int y, int width, int height, int dx, int dy);
    void draw() const;

    void move(int dx, int dy);
};

#endif