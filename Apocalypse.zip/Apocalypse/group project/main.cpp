#include <graphics.h>
#include <conio.h>
#include <cstdlib>
#include <ctime>
#include "plane.hpp"
#include "Sky.hpp"
#include "player.hpp"
#include "enemy.hpp"

int main()
{
    int screenWidth = getmaxwidth();
    int screenHeight = getmaxheight();

    initwindow(screenWidth, screenHeight, "Apocalypse");

    const int MIN_X = 50;
    const int MAX_X = screenWidth - 50;

    unsigned seed = time(0);
    srand(seed);

    Sky r1(0, 0, screenWidth, screenHeight, BLACK);
    Player p1(100, 100, 50, 50, 0, 0);
    //Enemy e1(100, 0, 50, 50, 0, 0)
    // x, y, width, height, dx, dy
    Enemy obj[500]; // Initializing enemy numbers
    Point objP[500];

    p1.setSky(&r1);
    //e1.setSky(&r1);

    for (int i = 0; i < 500; i++)
    {
        int spawn = (rand() % (MAX_X - MIN_X + 1)) + MIN_X;
        obj[i].setSky(&r1);
        obj[i].setX(spawn);
        obj[i].setWidth(50);
        obj[i].setHeight(50);
        obj[i].setDy(10);
    }

    r1.draw();
    //e1.draw();
    p1.draw();

    char c;
    while (true)
    {
        //delay(0);
        //e1.move();
        //c = 0;
        p1.draw();
        /*
        if (kbhit())
        {
            c = getch();
            c = toupper(c);
            if (c == 27)
                break;
        */

        /*
        if (c == 0)
        {
            c = getch();
        }
        */
        //int iterator = 0;
        //obj[iterator].draw();
        
            obj[i].move();
    
        c = getch();

        switch (c)
        {
        case KEY_LEFT:

            p1.move(-5, 0);
            break;
        case KEY_RIGHT:

            p1.move(5, 0);
            break;
        case KEY_UP:

            p1.move(0, -5);
            break;
        case KEY_DOWN:

            p1.move(0, 5);
            break;
        }
    }

    return 0;
}