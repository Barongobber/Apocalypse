#ifndef ENEMY_H
#define ENEMY_H
#include "point.hpp"
#include "Sky.hpp"


class Enemy : public Plane
{
public:
    Enemy(Point location = 0, int width = 0, int height = 0, int dx = 0, int dy = 0);
    Enemy(int x = 0, int y = 0, int width = 0, int height = 0, int dx = 0, int dy = 0);
    void draw() const;

    void move();
};

#endif