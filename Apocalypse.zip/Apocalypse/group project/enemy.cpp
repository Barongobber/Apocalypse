#include "point.hpp"
#include "enemy.hpp"
#include "Sky.hpp"
#include <graphics.h>

Enemy ::Enemy(Point location, int width, int height, int dx , int dy ) : Plane(location, width, height, dx, dy)
{
}

Enemy ::Enemy(int x, int y , int width, int height, int dx, int dy) : Plane(x, y, width, height, dx, dy)
{
    
}

void Enemy::draw() const
{
    readimagefile("plane3.jpg", this->location.getX(), this->location.getY(), this->location.getX() + width, this->location.getY() + height);
}

void Enemy :: move()
{
    undraw();
    location.move(0, dy);

    /*
    if (getRight() >= r->getRight())
    {
        location.setX(r->getRight() - width);
    }

    else if (getX() <= r->getX())
    {
        location.setX(r->getX());
    }

    if (getBottom() >= r->getBottom())
    {
        location.setY(r->getBottom() - height);
    }

    else if (getY() <= r->getY())
    {
        location.setY(r->getY());
    }
    */
    draw();
}